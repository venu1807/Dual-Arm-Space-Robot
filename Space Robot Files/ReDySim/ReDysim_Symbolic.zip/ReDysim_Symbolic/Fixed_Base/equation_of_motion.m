torque_1 = I1z*ddth1 + I2z*ddth1 + I2z*ddth2 + a1^2*ddth1*m2 + d2x*g*m2*cos(th1 + th2) + a1*g*m2*cos(th1) + d1x*g*m1*cos(th1) - a1*d2x*dth2^2*m2*sin(th2) + 2*a1*d2x*ddth1*m2*cos(th2) + a1*d2x*ddth2*m2*cos(th2) - 2*a1*d2x*dth1*dth2*m2*sin(th2)

torque_2 = a1*d2x*m2*sin(th2)*dth1^2 + I2z*ddth1 + I2z*ddth2 + d2x*g*m2*cos(th1 + th2) + a1*d2x*ddth1*m2*cos(th2)

