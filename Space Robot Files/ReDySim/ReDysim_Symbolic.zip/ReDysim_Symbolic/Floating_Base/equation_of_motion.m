0 = ddx0*m0 + ddx0*m1 - d1x*ddph0*m1*sin(ph0 + th1) - d1x*ddth1*m1*sin(ph0 + th1) - (a0*ddph0*m1*sin(ph0))/2 - d1x*dph0^2*m1*cos(ph0 + th1) - d1x*dth1^2*m1*cos(ph0 + th1) - (a0*dph0^2*m1*cos(ph0))/2 - 2*d1x*dph0*dth1*m1*cos(ph0 + th1)

0 = ddy0*m0 + ddy0*m1 + d1x*ddph0*m1*cos(ph0 + th1) + d1x*ddth1*m1*cos(ph0 + th1) + (a0*ddph0*m1*cos(ph0))/2 - d1x*dph0^2*m1*sin(ph0 + th1) - d1x*dth1^2*m1*sin(ph0 + th1) - (a0*dph0^2*m1*sin(ph0))/2 - 2*d1x*dph0*dth1*m1*sin(ph0 + th1)

0 = 0

0 = I0z*ddph0 + I1z*ddph0 + I1z*ddth1 + (a0^2*ddph0*m1)/4 + d1x^2*ddph0*m1 + d1x^2*ddth1*m1 + d1x*ddy0*m1*cos(ph0 + th1) - d1x*ddx0*m1*sin(ph0 + th1) + (a0*ddy0*m1*cos(ph0))/2 - (a0*ddx0*m1*sin(ph0))/2 - (a0*d1x*dth1^2*m1*sin(th1))/2 + a0*d1x*ddph0*m1*cos(th1) + (a0*d1x*ddth1*m1*cos(th1))/2 - a0*d1x*dph0*dth1*m1*sin(th1)

0 = 0

0 = 0

torque_1 = I1z*ddph0 + I1z*ddth1 + d1x^2*ddph0*m1 + d1x^2*ddth1*m1 + d1x*ddy0*m1*cos(ph0 + th1) - d1x*ddx0*m1*sin(ph0 + th1) + (a0*d1x*dph0^2*m1*sin(th1))/2 + (a0*d1x*ddph0*m1*cos(th1))/2

